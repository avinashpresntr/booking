
<style>
  .footerCoord{
    float:left;
    width: 100%;
    background-color: #f0eff0;
    color: black;
    text-align:center;
    padding: 10px;
    z-index: 11;
  }
  .footerCoord a{
    cursor:pointer;
    color: black;
  }
</style>

<div style="" class="footerCoord">
  Golf-Club Crans-sur-Sierre - Rue du Prado 20 - 3963 Crans-Montana - +41 (0)27 485 97 97 - <a href="mailto:info@golfcrans.ch">info@golfcrans.ch</a>
</div>

<footer>
  <style>
    .conditions{
      color:black;
      cursor:pointer;
    }
    .conditions:hover{
      color: #f8cc06 !important;
    }
  </style>
  <div class="copyright-footer" style="float:left; width: 50%; text-align:left;">
    <a style="margin-right:15px;" href="/en/conditions" class="conditions">Conditions générales</a>
    <a href="/en/contact" class="conditions">Contact</a>
  </div>
  <div class="copyright-footer" style="float:left; width: 50%; text-align:right;">© Golf-Club Crans-sur-Sierre 2016 - Created by iomedia</div>
</footer>